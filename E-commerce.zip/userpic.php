<!DOCTYPE html>
<head>
    <title>uploading a file</title>
    <style>
        body{
            background-image:url("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR1QRiHP6gZdkHWCr9mptLNCR3BF5Fu1OKTSadJVEDxQLEz8IMocf5sAI5Pu-XXKiQWb9M&usqp=CAU");
  background-repeat:no-repeat;
  background-size: cover;
        }
        img{
            height:150px;
            width:150px;
            border-radius: 50%;
            object-fit: cover;
            background:#dfdfdf;
        }
        button {
  padding: 15px 30px;
  font-size: 18px;
  outline: none;
  border: none;
  border-radius: 10px;
  transition: 0.5s;
  background: #1e1e1e;
  color: greenyellow;
  box-shadow: 0 0 10px #363636, inset 0 0 10px #363636;
}

button:hover {
  animation: a 0.5s 1 linear;
}

@keyframes a {
  0% {
    transform: scale(0.7, 1.3);
  }

  25% {
    transform: scale(1.3, 0.7);
  }

  50% {
    transform: scale(0.7, 1.3);
  }

  75% {
    transform: scale(1.3, 0.7);
  }

  100% {
    transform: scale(1, 1);
  }
}
    </style>
</head>
<body>
    <br><br><br><br><br><br><br><br>
    <center>
    <img src=""/>
    <input type="file">
    <button>
       <a href="main.php" style="text-decoration: none; color:white"> Next
      </a></button>
</body>

</html>
