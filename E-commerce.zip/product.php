<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Products</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    /* navbar*/
/*gallery*/
    :root {
  font-family: sans-serif;
  font-size: 16px;
}

* {
  box-sizing: border-box;
  background-color: #11131e;
}

body::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
body {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}

.content {
  width: 100%;
  margin: auto;
}
@media (min-width: 40em) {
  .content {
    width: 40em;
  }
}
@media (min-width: 80em) {
  .content {
    width: 80em;
  }
}

h1{
  color: #fff;
}

.gallery {
  display: flex;
  flex-flow: row wrap;
  align-content: flex-start;
  align-items: stretch;
  width: 100%;
  margin: auto;
}
.gallery .galleryItem {
  flex: 1 1 auto;
  margin: 0.3em;
  border: 1px solid black;
  position: relative;
  width: 12em;
  height: 13em;
  overflow: hidden;
}
@media (min-width: 40em) {
  .gallery .galleryItem {
    width: 10em;
    height: 10em;
  }
}
@media (min-width: 80em) {
  .gallery .galleryItem {
    width: 17em;
    height: 17em;
  }
}
.gallery .galleryItem:hover img {
  transform: scale(1.2);
}
.gallery a {
  display: block;
  width: 100%;
  height: 100%;
}
.gallery img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: 0.2s;
}
.gallery figcaption {
  background-color: rgba(0, 0, 0, 0.4);
  color: #fff;
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 1em;
}

.lightBoxOverlay {
  display: block;
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  background-color: rgba(0, 0, 0, 0.7);
}
.lightBoxOverlay .closeButton {
  position: absolute;
  top: 0.5em;
  right: 0.5em;
  color: #000;
  background-color: #fff;
  font-size: 1.5em;
  border-radius: 1em;
  padding: 0.44em 0.66em;
  height: 2em;
  width: 2em;
  cursor: pointer;
  transition: 0.2s;
}
.lightBoxOverlay .closeButton:hover {
  color: #fff;
  background-color: #000;
}
@media (min-width: 80em) {
  .lightBoxOverlay .closeButton {
    font-size: 2em;
    top: 1em;
    right: 1em;
    height: 2em;
    width: 2em;
  }
}
.lightBoxOverlay .container {
  margin: 0;
  display: flex;
  flex-flow: column nowrap;
  justify-content: center;
  align-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  padding: 1em;
}
@media (min-width: 40em) {
  .lightBoxOverlay .container {
    padding: 3em;
  }
}
@media (min-width: 80em) {
  .lightBoxOverlay .container {
    padding: 5em;
  }
}
.lightBoxOverlay img {
  max-width: 100%;
  max-height: 100%;
}
.lightBoxOverlay figcaption {
  margin-top: 1em;
  padding: 0.5em 1em;
  color: #fff;
  background: rgba(0, 0, 0, 0.7);
  border-radius: 5em;
}
</style>

</head>
<body>
<!-- partial:index.partial.html -->
<div class="content">
    <h1>Add to cart</h1>
    <div class="gallery">
        <figure class="galleryItem">
            <a href="#"><img src="https://media.istockphoto.com/id/1432271452/photo/tomatoes-in-the-market.webp?b=1&s=170667a&w=0&k=20&c=jY9wp-WAFZkg_kRcVoFexigbAooPt1ACLLvefVYyW18=" alt="Plant"></a>
            <figcaption>Tomato</figcaption>
        </figure>
        <figure class="galleryItem">
            <a href="#"><img src="https://media.istockphoto.com/id/1181631588/photo/onions-for-sale-in-the-weekly-market-malkapur-maharashtra.webp?b=1&s=170667a&w=0&k=20&c=y2uF8XGTlpT4cKjDzYNIID0Hjw1Ld5SGxAAnhDOVxHo=" alt="Man with facial tattoo"></a>
            <figcaption>Onion</figcaption>
        </figure>
        <figure class="galleryItem">
            <a href="#"><img src="https://images.unsplash.com/photo-1560252030-9fc63cb78dac?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fGJlYW5zfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60" alt="Leasure"></a>
            <figcaption>Beans</figcaption>
        </figure>
        <figure class="galleryItem">
            <a href="#"><img src="https://media.istockphoto.com/id/1251375199/photo/fresh-daikon-on-a-market-stall-in-delhi-india.jpg?s=612x612&w=0&k=20&c=PVqzGosfg0Dess6CzCw5Wj8-yQAYFlu7MTuaJFw4UsU=" alt="Pretty colors"></a>
            <figcaption>Raddish</figcaption>
        </figure>
        <figure class="galleryItem">
            <a href="#"><img src="https://media.istockphoto.com/id/1320448108/photo/brinjal-black-beauty-vegetable.webp?b=1&s=170667a&w=0&k=20&c=h35J0DkUDZnJmVYrErGMeaQWEPhtsInNVVhzrvJ7c-s=" alt="Architecture"></a>
            <figcaption>Bringal</figcaption>
        </figure>
        <figure class="galleryItem">
            <a href="#"><img src="https://images.unsplash.com/photo-1513553404607-988bf2703777?ixlib=rb-1.2.1&q=10&fm=jpg&crop=entropy&cs=srgb&ixid=eyJhcHBfaWQiOjE0NTg5fQ" alt="Beach"></a>
            <figcaption>Beach</figcaption>
        </figure>
        <figure class="galleryItem">
            <a href="#"><img src="https://images.unsplash.com/photo-1519405530001-3b5e82ba4dac?ixlib=rb-1.2.1&q=10&fm=jpg&crop=entropy&cs=srgb&ixid=eyJhcHBfaWQiOjE0NTg5fQ" alt="Mountains"></a>
            <figcaption>Mountains</figcaption>
        </figure>
    </div>
</div>
<!-- partial -->
  <script  src="./script.js"></script>

</body>
</html> 
</body>
<!--<script> //This is for download our pic by an url
    const urlInput = document.querySelector("input");
    const downloadBtn = document.querySelector("button");

    downloadBtn.addEventListener("click", async () => {
        try{
            const response = await fetch(urlInput.value);
            const file = await response.blob();
            const link = document.createElement("a");
            link.href = URL.createObjectURL(file);
            link.download = new Date().getTime();
            link.click();
        }catch(error) {
            alert("Failed to download the file!");
        }
    });
    </script>-->
</html>
