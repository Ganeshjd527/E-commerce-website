<html>
  <head>
    <title>pagechecker</title>
    <style>
      body{
        background-image:url('https://images.pexels.com/photos/3265437/pexels-photo-3265437.jpeg?auto=compress&cs=tinysrgb&w=1600');
        background-size: cover;
        background-repeat: no-repeat;
      }
      .login-card {
  width: 490px;
  height: 290px;
  background-color: #f2f2f2;
  border-radius: 25px;
  box-shadow: 2px 2px 15px rgb(193, 193, 193);
  justify-content:center;
}

.instruction-text {
  color: rgb(150, 150, 150);
  text-align: center;
  font-size: 15px;
  margin-top: 10px;
  margin-bottom: 15px;
}

.login-card button {
  cursor: pointer;
}

.normal-signin {
  padding: 15px;
  font-size: 17px;
  width: 70%;
  margin-top: 25px;
  margin-left: 10px;
  border: 2px solid transparent;
  border-radius: 5em;
  background-color: #1b77da;
  color: #f2f2f2;
  font-weight: bold;
  font-family: sans-serif;
  transition: 0.2s;
}

.normal-signin:hover {
  background-color: transparent;
  color: #1b77da;
  border: 2px solid #1b77da;
}

.create-account {
  padding: 10px;
  font-size: 17px;
  width: 70%;
  margin-top: 5px;
  margin-left: 10px;
  margin-bottom: 5px;
  border: 2px solid transparent;
  border-radius: 5em;
  background-color: #e8e8e8;
  color: #1b77da;
  font-weight: bold;
  font-family: sans-serif;
  transition: 0.2s;
}

.create-account:hover {
  background-color: transparent;
  color: #1b77da;
  border: 2px solid #1b77da;
}

.alternate-login {
  margin-left: 10px;
  margin-top: 5px;
  background-color: #f2f2f2;
  border-radius: 5em;
}

.m-sign {
  padding: 7px;
  font-size: 14px;
  height: 40px;
  width: 40px;
  border-radius: 5em;
  margin-top: 5px;
  background-color: #7FBA00;
  border: 2px solid transparent;
  transition: 0.2s;
}

.m-sign svg {
  width: 27px;
  height: 27px;
  margin-top: -2px;
  margin-left: -2px;
  fill: #f2f2f2;
}

.m-sign:hover {
  background-color: transparent;
  border: 2px solid #7FBA00;
}

.m-sign:hover svg {
  fill: #7FBA00;
}

.g-sign {
  padding: 7px;
  font-size: 14px;
  height: 40px;
  width: 40px;
  border-radius: 5em;
  margin-top: 5px;
  margin-left: 15px;
  background-color: #DB4437;
  border: 2px solid transparent;
  transition: 0.2s;
}

.g-sign svg {
  width: 23px;
  height: 25px;
  margin-top: -1.5px;
  fill: #f2f2f2;
}

.g-sign:hover {
  background-color: transparent;
  border: 2px solid #DB4437;
}

.g-sign:hover svg {
  fill: #DB4437;
}

.a-sign {
  padding: 7px;
  font-size: 14px;
  height: 40px;
  width: 40px;
  border-radius: 5em;
  margin-top: 5px;
  margin-left: 15px;
  background-color: #000000;
  border: 2px solid transparent;
  transition: 0.2s;
}

.a-sign svg {
  width: 25px;
  height: 25px;
  margin-top: -1px;
  margin-left: -1px;
  fill: #f2f2f2;
}

.a-sign:hover {
  background-color: transparent;
  border: 2px solid #000000;
}

.a-sign:hover svg {
  fill: #000000;
}
/*button home*/
button {
  padding: 1.3em 3em;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 2.5px;
  font-weight: 500;
  color: #000;
  background-color: #fff;
  border: none;
  border-radius: 45px;
  box-shadow: 0px 8px 15px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease 0s;
  cursor: pointer;
  outline: none;
}

button:hover {
  background-color: #23c483;
  box-shadow: 0px 15px 20px rgba(46, 229, 157, 0.4);
  color: #fff;
  transform: translateY(-7px);
}

button:active {
  transform: translateY(-1px);
}
</style>
<body><br><br><br><br><br><br><br><br><br><br><center>
<div class="login-card"><center>
  <button class="normal-signin"><a href="loginacc.php" style="text-decoration:none; color:blue">Log in</a></button>
  <div class="instruction-text">Don't have an Account?</div><center>
  <button class="create-account"><a href="createacc.php" style="text-decoration:none; color:blue  ">Create Account</a></button>
  <div class="instruction-text">Or sign in with</div><center>
  <div class="alternate-login">
    <button class="m-sign">
      <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
<path d="M4 4H11.5V11.5H4V4ZM12.5 4H20V11.5H12.5V4ZM4 12.5H11.5V20H4V12.5ZM12.5 12.5H20V20H12.5V12.5Z"></path>
</svg>
    </button>
    <button class="g-sign">
      <svg viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Page-1" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Dribbble-Light-Preview" transform="translate(-300.000000, -7399.000000)">
            <g id="icons" transform="translate(56.000000, 160.000000)">
                <path d="M263.821537,7247.00386 L254.211298,7247.00386 C254.211298,7248.0033 254.211298,7250.00218 254.205172,7251.00161 L259.774046,7251.00161 C259.560644,7252.00105 258.804036,7253.40026 257.734984,7254.10487 C257.733963,7254.10387 257.732942,7254.11086 257.7309,7254.10986 C256.309581,7255.04834 254.43389,7255.26122 253.041161,7254.98137 C250.85813,7254.54762 249.130492,7252.96451 248.429023,7250.95364 C248.433107,7250.95064 248.43617,7250.92266 248.439233,7250.92066 C248.000176,7249.67336 248.000176,7248.0033 248.439233,7247.00386 L248.438212,7247.00386 C249.003881,7245.1669 250.783592,7243.49084 252.969687,7243.0321 C254.727956,7242.65931 256.71188,7243.06308 258.170978,7244.42831 C258.36498,7244.23842 260.856372,7241.80579 261.043226,7241.6079 C256.0584,7237.09344 248.076756,7238.68155 245.090149,7244.51127 L245.089128,7244.51127 C245.089128,7244.51127 245.090149,7244.51127 245.084023,7244.52226 L245.084023,7244.52226 C243.606545,7247.38565 243.667809,7250.75975 245.094233,7253.48622 C245.090149,7253.48921 245.087086,7253.49121 245.084023,7253.49421 C246.376687,7256.0028 248.729215,7257.92672 251.563684,7258.6593 C254.574796,7259.44886 258.406843,7258.90916 260.973794,7256.58747 C260.974815,7256.58847 260.975836,7256.58947 260.976857,7256.59047 C263.15172,7254.63157 264.505648,7251.29445 263.821537,7247.00386" id="google-[#178]">

</path>
            </g>
        </g>
    </g>
</svg>
    </button>
    <button class="a-sign">
      <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="-145 129 220 256" xml:space="preserve">
<path d="M75,316.8c-6,13.3-8.9,19.3-16.6,31c-10.8,16.4-26,36.9-44.9,37.1c-16.8,0.2-21.1-10.9-43.8-10.8
	c-22.7,0.1-27.5,11-44.3,10.8c-18.9-0.2-33.3-18.7-44.1-35.1c-30.2-46-33.4-99.9-14.7-128.6c13.2-20.4,34.1-32.3,53.8-32.3
	c20,0,32.5,11,49.1,11c16,0,25.8-11,48.9-11c17.5,0,36,9.5,49.2,26C24.3,238.6,31.3,300.3,75,316.8L75,316.8z M0.8,170.6
	c8.4-10.8,14.8-26,12.5-41.6c-13.7,0.9-29.8,9.7-39.1,21.1c-8.5,10.3-15.5,25.6-12.8,40.5C-23.7,191.1-8.2,182.1,0.8,170.6
	L0.8,170.6z"></path>
</svg>
    </button>
  </div>
</div><br><br><br><br><br><br><br><br>
<button><a href="main.php" style="text-decoration:none;color:black"> Back to home</a></button>
<body>
  </html>