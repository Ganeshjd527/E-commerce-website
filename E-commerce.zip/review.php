<!--doctype html-->
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1.0">
<title>Review page</title>
<!--Stylesheet--------------------------->
<link rel="stylesheet" href="css/style.css"/>
<!--Fav-icon------------------------------>
<link rel="shortcut icon" href="images/fav-icon.png"/>
<!--poppins-font-family------------------->
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<!--using-Font-Awesome-------------------->
<style> 
body{
    background-image:url('https://media.istockphoto.com/id/1287274564/photo/wood-cube-with-check-mark-on-blue-background-checklist-concept-copy-space.webp?b=1&s=170667a&w=0&k=20&c=E6xcmfu7gTsibVrcaqME-zwioqu2cVSCAAS8gSY1eEM=');
    background-repeat:no-repeat;
    background-size:cover;
}
  * {
    margin: 0px;
    padding: 0px;
    font-family: poppins;
    box-sizing: border-box;
}
   *{
    text-decoration: none;
}
.testimonials{
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    width:100%;
}
.testimonial-heading{
    letter-spacing: 1px;
    margin: 30px 0px;
    padding: 10px 20px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}
.testimonial-heading h1{
    font-size: 2.2rem;
    font-weight: 500;
    background-color: #202020;
    color: #ffffff;
    padding: 10px 20px;
}
.testimonial-heading span{
    font-size: 1.3rem;
    color: #252525;
    margin-bottom: 10px;
    letter-spacing: 2px;
    text-transform: uppercase;
}
.testimonial-box-container{
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    width:100%;
    
}
.testimonial-box{
    width:500px;
    box-shadow: rgba(0, 0, 0, 0.56) 0px 22px 70px 4px;
    background-color:black;
    padding: 20px;
    margin: 15px;
    cursor: pointer;
    border-radius:20%;
}
.profile-img{
    width:50px;
    height: 50px;
    border-radius: 50%;
    overflow: hidden;
    margin-right: 10px;
}
.profile-img img{
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center;
}
.profile{
    display: flex;
    align-items: center;
}
.name-user{
    display: flex;
    flex-direction: column;
}
.name-user strong{
    color:white;
    font-size: 1.1rem;
    letter-spacing: 0.5px;
}
.name-user span{
    color: #979797;
    font-size: 0.8rem;
}
.reviews{
    color: #f9d71c;
}
.box-top{
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}
.client-comment p{
    font-size: 0.9rem;
    color: #4b4b4b;
}
.testimonial-box:hover{
    transform: translateY(-10px);
    transition: all ease 0.3s;
}
 
@media(max-width:1060px){
    .testimonial-box{
        width:25%;
        padding: 10px;
    }
}
@media(max-width:500px){
    .testimonial-box{
        width:100%;
    }
    .testimonial-heading h1{
        font-size: 1.4rem;
    }
}
@media(max-width:340px){
    .box-top{
        flex-wrap: wrap;
        margin-bottom: 10px;
    }
    .reviews{
        margin-top: 10px;
    }
}
::selection{
    color: #ffffff;
    background-color: #252525;
}
</style>
</head>
<body>
    <center>
        <dic class="testimonials">
    <section id="REVIEWS">
        <div class="Review">
            <h1>Comments</h1>
            <h3>Clients says</h3>
        </div><br><br><br>
        <div class="testimonial-box-container">
            <div class="testimonial-box">
                <div class="box-top">
                    <div class="profile">
                        <div class="profile-img">
                            <img src="https://images.pexels.com/photos/3941855/pexels-photo-3941855.jpeg?auto=compress&cs=tinysrgb&w=1600">
                        </div>
                        <div class="name-user">
                            <strong>Anandangeethu</strong>
                            <span>@Dev1109</span>
                        </div>
                    </div>
                    <div class="reviews">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i><!--Empty star-->
                    </div>
                </div><br>
                <div class="client-comment">
                    <p>This website is just awsome and go for it without wasting time .the quality of service is outstanding as well the genuine gesture of the client queries made me to keep on shopping</p>
            </div></div>
            <div class="testimonial-box">
                <div class="box-top">
                    <div class="profile">
                        <div class="profile-img">
                            <img src="https://images.pexels.com/photos/1583244/pexels-photo-1583244.jpeg?auto=compress&cs=tinysrgb&w=1600" />
                        </div>
                        <div class="name-user">
                            <strong>Lakshmikali</strong>
                            <span>@Latchu</span>
                        </div>
                    </div>
                    <div class="reviews">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i><!--Empty star-->
                    </div>
                </div><br>
                <div class="client-comment">
                    <p>The website is just awsome and the vegetables are very fresh and its direct from the form yard i feel very happy to eat healthy .</p>
                </div>
            </div>
            <div class="testimonial-box">
                <div class="box-top">
                    <div class="profile">
                        <div class="profile-img">
                            <img src="https://images.pexels.com/photos/672630/pexels-photo-672630.jpeg?auto=compress&cs=tinysrgb&w=1600" />
                                                </div>
                        <div class="name-user">
                            <strong>Sai Anand</strong>
                            <span>@saind1309</span>
                        </div>
                    </div>
                    <div class="reviews">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i><!--Empty star-->
                    </div>
                </div><br>
                <div class="client-comment">
                    <p> Hlo freaks,when you are searching for a healthy shop from your home just go and rock with GO-GROC  - its your hope</p>
                </div>
            </div>
            <div class="testimonial-box">
                <div class="box-top">
                    <div class="profile">
                        <div class="profile-img">
                            <img src="https://images.pexels.com/photos/1308881/pexels-photo-1308881.jpeg?auto=compress&cs=tinysrgb&w=1600" />
                        </div><br>
                        <div class="name-user">
                            <strong>Cherini6578</strong>
                            <span>@CDR</span>
                        </div>
                    </div>
                    <div class="reviews">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i><!--Empty star-->
                    </div>
                </div>
                <div class="client-comment">
                    <p>Lets rock it with GO-GROC the perfect page for healthy shop !!especially the products are 100% organic and robust delivery make gogroc shop....# Have shop Have fun</p>
                </div>
            </div>
        </div>
</div>
</div>
    </section>
</body>
<script src="https://kit.fontawesome.com/c8e4d183c2.js" crossorigin="anonymous">


</script>
</html>