<!DOCTYPE html>
<html>
<head>
  <title>Deviks</title>
  <style>
    /* Global Styles */
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0px;
  padding: right;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
  
}

/* Header Styles */
header {
  background-color: #f8f8f8;
  padding: right;
  right: 200px;
  position:fixed;
  width: 0 auto;
  height:0;
}

/* Fixed Navbar Styles */
nav {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  background-color: #f8f8f8;
  z-index: 100;
  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
  font-weight: bold;
}

nav ul {
  display: flex;
  justify-content: right;
  align-items: center;
  height: 30px;
}

nav ul li {
  margin-right: 8px;
  font-size: 18px;
}

nav ul li a {
  display: block;
  padding: 12px 20px;
  text-decoration: none;
  color: #333;
  transition:0.3s ease;
}

nav ul li a:hover {
  background-color: rgb(255, 208, 0);
  border-radius: 20px;
  color: black;
  font-weight: bold;
}
/* Hero Section Styles */
.hero {
 background-image:url('logo/loginpic.png');
  background-size:cover;
  background-repeat: no-repeat;
  text-align: center;
  padding: 300px 0;
  font-family: 'Merriweather', serif;
  font-family: 'Roboto', sans-serif;
  font-family: 'Roboto Slab', serif;
  width:100%;
}

.hero h1 {
  font-size: 40px;
  margin-bottom: 20px;
}

.hero p {
  font-size: 25px;
  margin-bottom: 0px;
}

/* About Section Styles */
.about {
  background-image:url('https://images.unsplash.com/photo-1495195129352-aeb325a55b65?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OXx8dmVnZXRhYmxlcyUyMGJhY2tncm91bmR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60');
  background-size:cover;
  background-repeat: no-repeat;
  padding: 300px 0;
}

.about h2 {
  font-size: 50px;
  margin-bottom: 20px;
  justify-content:center;
  text-align:center;
  font-family: 'Gideon Roman';
}
p{
  font-size:30px;
  font-family: 'Gideon Roman';
}
/* Projects Section Styles*/
.projects {
  text-align: center;
  padding: 60px 0;
}

.projects h2 {
  font-size: 24px;
  margin-bottom: 20px;
}

.project {
  display: inline-block;
  width: 250px;
  margin: 20px;
  text-align: left;
}

.project img {
  width: 100%;
  max-height: 200px;
  object-fit:;
}

.project h3 {
  font-size: 18px;
  margin: 10px 0;
}

.project p {
  font-size: 14px;
  margin: 0px 0;
}
/*view product*/

/* Contact Section Styles */

/* Footer Styles */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
.container{
	max-width: 1170px;
	margin:auto;
  padding: 400 0;
}
.row{
	display: flex;
	flex-wrap: wrap;
}
ul{
	list-style: none;
}
.footer{
	background-color: #24262b;
    padding: 70px 0;
}
.footer-col{
   width: 25%;
   padding: 0 15px;
}
.footer-col h4{
	font-size: 18px;
	color: #ffffff;
	text-transform: capitalize;
	margin-bottom: 35px;
	font-weight: 500;
	position: relative;
}
.footer-col h4::before{
	content: '';
	position: absolute;
	left:0;
	bottom: -10px;
	background-color: #e91e63;
	height: 2px;
	box-sizing: border-box;
	width: 50px;
}
.footer-col ul li:not(:last-child){
	margin-bottom: 10px;
}
.footer-col ul li a{
	font-size: 16px;
	text-transform: capitalize;
	color: #ffffff;
	text-decoration: none;
	font-weight: 300;
	color: #bbbbbb;
	display: block;
	transition: all 0.3s ease;
}
.footer-col ul li a:hover{
	color: #ffffff;
	padding-left: 8px;
}
.footer-col .social-links a{
	display: inline-block;
	height: 40px;
	width: 40px;
	background-color: rgba(255,255,255,0.2);
	margin:0 10px 10px 0;
	text-align: center;
	line-height: 40px;
	border-radius: 50%;
	color: #0f0505;
	transition: all 0.5s ease;
}
.footer-col .social-links a:hover{
	color: #24262b;
	background-color: #ffffff;
        
}

/responsive/
@media(max-width: 767px){
  .footer-col{
    width: 50%;
    margin-bottom: 30px;
}
}
@media(max-width: 574px){
  .footer-col{
    width: 100%;
}
}
/*loader*/
.loader {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: #f8f8f8;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
}

.loader-inner {
  border: 3px solid blue;
  border-top: 3px solid transparent;
  border-radius: 50%;
  width: 50px;
  height: 50px;
  animation: spin 1s infinite linear;
}

@keyframes spin {
  0% {
    transform: rotate(0);
  }
  100% {
    transform: rotate(360deg);
  }
}

.content {
  /* Add styles for your website content */
  display: none;
}
/*loader over*/
/*button*/
.button2 {
  display: inline-block;
  transition: all 0.2s ease-in;
  position: relative;
  overflow: hidden;
  z-index: 1;
  color: #090909;
  padding: 0.7em 1.7em;
  font-size: 18px;
  justify-content:right;
  border-radius: 0.5em;
  background: #e8e8e8;
  border: 1px solid #e8e8e8;
  box-shadow: 6px 6px 12px #c5c5c5,;
}

.button2:active {
  color: #666;
  box-shadow: inset 4px 4px 12px #c5c5c5,
             inset -4px -4px 12px #ffffff;
}

.button2:before {
  content: "";
  position: absolute;
  left: 50%;
  transform: translateX(-50%) scaleY(1) scaleX(1.25);
  top: 100%;
  width: 140%;
  height: 180%;
  background-color: rgba(0, 0, 0, 0.05);
  border-radius: 50%;
  display: block;
  transition: all 0.5s 0.1s cubic-bezier(0.55, 0, 0.1, 1);
  z-index: -1;
}

.button2:after {
  content: "";
  position: absolute;
  left: 55%;
  transform: translateX(-50%) scaleY(1) scaleX(1.45);
  top: 180%;
  width: 160%;
  height: 190%;
  background-color: #009087;
  border-radius: 50%;
  display: block;
  transition: all 0.5s 0.1s cubic-bezier(0.55, 0, 0.1, 1);
  z-index: -1;
}

.button2:hover {
  color: #ffffff;
  border: 1px solid #009087;
}

.button2:hover:before {
  top: -35%;
  background-color: #009087;
  transform: translateX(-50%) scaleY(1.3) scaleX(0.8);
}

.button2:hover:after {
  top: -45%;
  background-color: #009087;
  transform: translateX(-50%) scaleY(1.3) scaleX(0.8);
}
/*social media*/
.main {
  display: flex;
  flex-direction: column;
  gap: 0.5em;
}

.up {
  display: flex;
  flex-direction: row;
  gap: 0.5em;
}

.down {
  display: flex;
  flex-direction: row;
  gap: 0.5em;
}

.card1 {
  width: 90px;
  height: 90px;
  outline: none;
  border: none;
  background: white;
  border-radius: 90px 5px 5px 5px;
  box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
  transition: .2s ease-in-out;
}

.instagram {
  margin-top: 1.5em;
  margin-left: 1.2em;
  fill: #cc39a4;
}

.card2 {
  width: 90px;
  height: 90px;
  outline: none;
  border: none;
  background: white;
  border-radius: 5px 90px 5px 5px;
  box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
  transition: .2s ease-in-out;
}

.twitter {
  margin-top: 1.5em;
  margin-left: -.9em;
  fill: #03A9F4;
}

.card3 {
  width: 90px;
  height: 90px;
  outline: none;
  border: none;
  background: white;
  border-radius: 5px 5px 5px 90px;
  box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
  transition: .2s ease-in-out;
}

.github {
  margin-top: -.6em;
  margin-left: 1.2em;
}

.card4 {
  width: 90px;
  height: 90px;
  outline: none;
  border: none;
  background: white;
  border-radius: 5px 5px 90px 5px;
  box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
  transition: .2s ease-in-out;
}

.discord {
  margin-top: -.9em;
  margin-left: -1.2em;
  fill: #8c9eff;
}

.card1:hover {
  cursor: pointer;
  scale: 1.1;
  background-color: #cc39a4;
}

.card1:hover .instagram {
  fill: white;
}

.card2:hover {
  cursor: pointer;
  scale: 1.1;
  background-color: #03A9F4;
}

.card2:hover .twitter {
  fill: white;
}

.card3:hover {
  cursor: pointer;
  scale: 1.1;
  background-color: black;
}

.card3:hover .github {
  fill: white;
}

.card4:hover {
  cursor: pointer;
  scale: 1.1;
  background-color: #8c9eff;
}

.card4:hover .discord {
  fill: white;
}
/*add to cart*/
.CartBtn {
  width: 140px;
  height: 40px;
  border-radius: 12px;
  border: none;
  background-color: rgb(255, 208, 0);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition-duration: .5s;
  overflow: hidden;
  box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.103);
  position: relative;
}

.IconContainer {
  position: absolute;
  left: -50px;
  width: 30px;
  height: 30px;
  background-color: transparent;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  z-index: 2;
  transition-duration: .5s;
}

.icon {
  border-radius: 1px;
}

.text {
  height: 100%;
  width: fit-content;
  display: flex;
  align-items: center;
  justify-content: center;
  color: rgb(17, 17, 17);
  z-index: 1;
  transition-duration: .5s;
  font-size: 1.04em;
  font-weight: 600;
}

.CartBtn:hover .IconContainer {
  transform: translateX(58px);
  border-radius: 40px;
  transition-duration: .5s;
}

.CartBtn:hover .text {
  transform: translate(10px,0px);
  transition-duration: .5s;
}

.CartBtn:active {
  transform: scale(0.95);
  transition-duration: .5s;
}
/*headsearch*/
.InputContainer {
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: rgb(255, 255, 255);
  border-radius: 10px;
  overflow: hidden;
  cursor: pointer;
  padding-left: 15px;
  box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.075);
}

.input {
  width: 170px;
  height: 100%;
  border: none;
  outline: none;
  font-size: 0.9em;
  caret-color: rgb(255, 81, 0);
}

.labelforsearch {
  cursor: text;
  padding: 0px 12px;
}

.searchIcon {
  width: 13px;
}

.border {
  height: 40%;
  width: 1.3px;
  background-color: rgb(223, 223, 223);
}

.micIcon {
  width: 12px;
}

.micButton {
  padding: 0px 15px 0px 12px;
  border: none;
  background-color: transparent;
  height: 40px;
  cursor: pointer;
  transition-duration: .3s;
}

.searchIcon path {
  fill: rgb(114, 114, 114);
}

.micIcon path {
  fill: rgb(255, 81, 0);
}

.micButton:hover {
  background-color: rgb(255, 230, 230);
  transition-duration: .3s;
}
/*logo*/
img{
    width:
    aspect-ratio:;
    object-fit: ;
    mix-blend-mode: color-bright;
    left: 200%;
    filter: blur(-50px);
}
/*lastfooter*/
</style>
</head>
<body>
  <!--loader-->
  <div class="loader">
    <div class="loader-inner"></div>
  </div>

  <div class="content">
    <!-- Your website content goes here -->
  </div>
  <!--loader over-->
  <header>
    <nav>
      <ul>
      <img src="logo/ecommerce.png" alt="picture" height="62" width="100">
        <li><a href="#home">Home</a></li>
        <li><a href="#about">About</a></li>
        <li><a href="#projects">Products</a></li>
        <li><a href="#contact">Contact</a></li>
        <button class="CartBtn">
  <span class="IconContainer"> 
    <svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 576 512" fill="rgb(17, 17, 17)" class="cart">
      <path d="M0 24C0 10.7 10.7 0 24 0H69.5c22 0 41.5 12.8 50.6 32h411c26.3 0 45.5 25 38.6 50.4l-41 152.3c-8.5 31.4-37 53.3-69.5 53.3H170.7l5.4 28.5c2.2 11.3 12.1 19.5 23.6 19.5H488c13.3 0 24 10.7 24 24s-10.7 24-24 24H199.7c-34.6 0-64.3-24.6-70.7-58.5L77.4 54.5c-.7-3.8-4-6.5-7.9-6.5H24C10.7 48 0 37.3 0 24zM128 464a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zm336-48a48 48 0 1 1 0 96 48 48 0 1 1 0-96z"></path></svg>
  </span>
  <p class="text"><a href="addcartpage.php" style="text-decoration:none; color:black">Add to Cart</a></p>
</button>
<div class="InputContainer">
  <input type="text" name="text" class="input" id="input" placeholder="Search">
  
  <label for="input" class="labelforsearch">
<svg viewBox="0 0 512 512" class="searchIcon"><path d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z"></path></svg>
</label>
<div class="border"></div>

<button class="micButton"><svg viewBox="0 0 384 512" class="micIcon"><path d="M192 0C139 0 96 43 96 96V256c0 53 43 96 96 96s96-43 96-96V96c0-53-43-96-96-96zM64 216c0-13.3-10.7-24-24-24s-24 10.7-24 24v40c0 89.1 66.2 162.7 152 174.4V464H120c-13.3 0-24 10.7-24 24s10.7 24 24 24h72 72c13.3 0 24-10.7 24-24s-10.7-24-24-24H216V430.4c85.8-11.7 152-85.3 152-174.4V216c0-13.3-10.7-24-24-24s-24 10.7-24 24v40c0 70.7-57.3 128-128 128s-128-57.3-128-128V216z"></path></svg>
</button>

</div>
      </ul>
    </nav>
  </header>
  <section id="home" class="hero"><br><br><br><br><br><br>
    <h1 style="color:#cc0000"><u>"The freshest of vegetables"</u></h1><br>
    <p style="color:black"><b>We the veggie website -making farm product  at your door<br>
Every farmer approves of our greens.</b></p><br>
<i style="color:black"><b>"Vegetables are a healthy choice for a wealthy mind" Happy and Healthy shop via  GOGROC <br><br><br>-Its YourHope</b></i>
  </section>

  <section id="about" class="about" href="product.php">
    <h2 style="color:black;">About us</h2>
    <p style="color:black; text-align:center"><b>Keeping your eye on the ball while performing a deep dive on the start-up mentality<br>
      to derive convergence on cross-platform integration. Objectively innovate empowered<br>
      Vegetable products service  at your door.Holisticly predominate extensible testing<br>
       procedures for reliable quality and ensuring our robust-delivery supply chains.<br>
        Dramatically engage top-line online veggy shopping<br>
       services vis-a-vis cutting-edge deliverables "we care for your health,keep shopping"</b></p>
    <a href="product.php"></a>
  </section>

  <section id="projects" class="projects">
    <h2>Products</h2>
    <div class="project">
      <img src="https://media.istockphoto.com/id/1369929551/photo/organic-tomatoes-sale-on-market-stall.jpg?s=612x612&w=0&k=20&c=tiW7iNuqCnuN0HoE4yDqkUbt17j8f8kEUKcwvYvcvbQ=" alt="Project 1">
      <h3>Tomato</h3>
      <p>Tomato is a versatile and widely consumed fruit that is often mistaken as a vegetable due to 
        its culinary uses.</p>
    </div>
    <div class="project">
      <img src="https://media.istockphoto.com/id/1181631588/photo/onions-for-sale-in-the-weekly-market-malkapur-maharashtra.jpg?s=612x612&w=0&k=20&c=KYz1slV6Ly-T7v2vH7jns7ab9i_M6Atjq52uNPh3gRo=" alt="Project 2">
      <h3>Onion</h3>
      <p>Onions,scientifically known as Allium cepa,are a widely used vegetable that belongs to the allium family.</p>
    </div>
    <div class="project">
      <img src="https://images.unsplash.com/photo-1560252030-9fc63cb78dac?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fGJlYW5zfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60" alt="Project 2" height="169">
      <h3>Beans</h3>
      <p>Beans, also known as legumes, are a group of plant species that belong to the Fabaceae family</p>
    </div>
    <div class="project">
      <img src="https://media.istockphoto.com/id/155375750/photo/red-apples-at-market.jpg?s=612x612&w=0&k=20&c=lmHinxPN20-nIm15ewPYetBPv0US4rYzACe8LOEbe-Q=" alt="Project 2">
      <h3>Apple</h3>
      <p>Juicy, crunchy, nutritious, versatile, refreshing, sweet, fiber-rich, iconic, antioxidant-rich, popular.</p>
    </div><br>
    <div class="project">
      <img src="https://media.istockphoto.com/id/482078328/photo/orange-background.jpg?s=612x612&w=0&k=20&c=A8DJm29nWNNadN1GhosubeWd5ddEzA7V3GRurmtGM88=" alt="Project 2">
      <h3>Orange</h3>
      <p>Citrusy, refreshing, vitamin C-rich, bright, tangy, aromatic, hydrating, versatile, zesty, immune-boosting.</p>
    </div>
    <div class="project">
      <img src="https://media.istockphoto.com/id/1320448108/photo/brinjal-black-beauty-vegetable.jpg?s=612x612&w=0&k=20&c=iVmck1hRiOqG5g-_UgWIgV00Vhe5z09Okg6qvkD90js=" alt="Project 2">
      <h3>Bringal</h3>
      <p>Nutritious, versatile, purple, fleshy, mild, egg-shaped, fiber-rich, roasted, curries, Mediterranean cuisine.</p>
    </div>
    <div class="project">
      <img src="https://media.istockphoto.com/id/183217648/photo/bunch-of-different-types-of-fresh-grapes.jpg?s=612x612&w=0&k=20&c=Uag1Gm9tL0HsGkdvE4L28qVkiANuoJZUCKzzOxautpc=" alt="Project 2" style="border-inline: double; border: radius 50px;">
      <h3>Grapes</h3>
      <p>
Sweet, juicy, bite-sized, versatile, antioxidant-rich, vine-grown, refreshing, colorful, wine-making, snackable.</p>
    </div>
    <!--<button><a href="anadand.html">View More</a></button>-->
    <!-- Add more projects as needed -->
  </section>
<!--contact us-->
  <section id="contact" class="contact">
    <footer  class ="footer">
        <div  class ="container">
            <div class="row">
                <div class="footer-col">
                    <h4>company</h4>
                    <ul>
                        <li><a  href="#">about us</a></li>
                        <li><a  href="#"> our services</a></li>
                        <li><a  href="#">privacy policy</a></li>
                        <li><a  href="#">affiliate program</a></li>
                    </ul>
</div>
<div class="footer-col">
<h4> get help</h4>
<ul>
    <li> <a href="#">FAQ</a></li>
    <li> <a  href="#">shipping</a></li>
    <li> <a  href="#">return</a></li>
    <li> <a  href="#">order status</a></li>  
    <li> <a  href="#">Payment Option</a></li>
</ul>
</div>
<div class="footer-col">
    <h4>online shop</h4>
    <ul>
        <li><a  href="#">Bag</a></li>
        <li><a  href="#">Fruits</a></li>
        <li><a  href="#">Grocery</a></li>
        <li><a  href="#">Organic perfumes</a></li>
    </ul>
</div>
<div class="footer-col">
    <h4>follow us </h4>
    <div class ="social-links">
    <div class="main">
  <div class="up">
    <button class="card1">
      <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0,0,256,256" width="30px" height="30px" fill-rule="nonzero" class="instagram"><g fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><g transform="scale(8,8)"><path d="M11.46875,5c-3.55078,0 -6.46875,2.91406 -6.46875,6.46875v9.0625c0,3.55078 2.91406,6.46875 6.46875,6.46875h9.0625c3.55078,0 6.46875,-2.91406 6.46875,-6.46875v-9.0625c0,-3.55078 -2.91406,-6.46875 -6.46875,-6.46875zM11.46875,7h9.0625c2.47266,0 4.46875,1.99609 4.46875,4.46875v9.0625c0,2.47266 -1.99609,4.46875 -4.46875,4.46875h-9.0625c-2.47266,0 -4.46875,-1.99609 -4.46875,-4.46875v-9.0625c0,-2.47266 1.99609,-4.46875 4.46875,-4.46875zM21.90625,9.1875c-0.50391,0 -0.90625,0.40234 -0.90625,0.90625c0,0.50391 0.40234,0.90625 0.90625,0.90625c0.50391,0 0.90625,-0.40234 0.90625,-0.90625c0,-0.50391 -0.40234,-0.90625 -0.90625,-0.90625zM16,10c-3.30078,0 -6,2.69922 -6,6c0,3.30078 2.69922,6 6,6c3.30078,0 6,-2.69922 6,-6c0,-3.30078 -2.69922,-6 -6,-6zM16,12c2.22266,0 4,1.77734 4,4c0,2.22266 -1.77734,4 -4,4c-2.22266,0 -4,-1.77734 -4,-4c0,-2.22266 1.77734,-4 4,-4z"></path></g></g></svg>
    </button>
    <button class="card2">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="30px" height="30px" class="twitter"><path d="M42,12.429c-1.323,0.586-2.746,0.977-4.247,1.162c1.526-0.906,2.7-2.351,3.251-4.058c-1.428,0.837-3.01,1.452-4.693,1.776C34.967,9.884,33.05,9,30.926,9c-4.08,0-7.387,3.278-7.387,7.32c0,0.572,0.067,1.129,0.193,1.67c-6.138-0.308-11.582-3.226-15.224-7.654c-0.64,1.082-1,2.349-1,3.686c0,2.541,1.301,4.778,3.285,6.096c-1.211-0.037-2.351-0.374-3.349-0.914c0,0.022,0,0.055,0,0.086c0,3.551,2.547,6.508,5.923,7.181c-0.617,0.169-1.269,0.263-1.941,0.263c-0.477,0-0.942-0.054-1.392-0.135c0.94,2.902,3.667,5.023,6.898,5.086c-2.528,1.96-5.712,3.134-9.174,3.134c-0.598,0-1.183-0.034-1.761-0.104C9.268,36.786,13.152,38,17.321,38c13.585,0,21.017-11.156,21.017-20.834c0-0.317-0.01-0.633-0.025-0.945C39.763,15.197,41.013,13.905,42,12.429"></path></svg>
    </button>
  </div>
  <div class="down">
    <button class="card3">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" width="30px" height="30px" class="github">    <path d="M15,3C8.373,3,3,8.373,3,15c0,5.623,3.872,10.328,9.092,11.63C12.036,26.468,12,26.28,12,26.047v-2.051 c-0.487,0-1.303,0-1.508,0c-0.821,0-1.551-0.353-1.905-1.009c-0.393-0.729-0.461-1.844-1.435-2.526 c-0.289-0.227-0.069-0.486,0.264-0.451c0.615,0.174,1.125,0.596,1.605,1.222c0.478,0.627,0.703,0.769,1.596,0.769 c0.433,0,1.081-0.025,1.691-0.121c0.328-0.833,0.895-1.6,1.588-1.962c-3.996-0.411-5.903-2.399-5.903-5.098 c0-1.162,0.495-2.286,1.336-3.233C9.053,10.647,8.706,8.73,9.435,8c1.798,0,2.885,1.166,3.146,1.481C13.477,9.174,14.461,9,15.495,9 c1.036,0,2.024,0.174,2.922,0.483C18.675,9.17,19.763,8,21.565,8c0.732,0.731,0.381,2.656,0.102,3.594 c0.836,0.945,1.328,2.066,1.328,3.226c0,2.697-1.904,4.684-5.894,5.097C18.199,20.49,19,22.1,19,23.313v2.734 c0,0.104-0.023,0.179-0.035,0.268C23.641,24.676,27,20.236,27,15C27,8.373,21.627,3,15,3z"></path></svg>
    </button>
    <button class="card4">
      <svg height="30px" width="30px" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" class="discord"><path d="M40,12c0,0-4.585-3.588-10-4l-0.488,0.976C34.408,10.174,36.654,11.891,39,14c-4.045-2.065-8.039-4-15-4s-10.955,1.935-15,4c2.346-2.109,5.018-4.015,9.488-5.024L18,8c-5.681,0.537-10,4-10,4s-5.121,7.425-6,22c5.162,5.953,13,6,13,6l1.639-2.185C13.857,36.848,10.715,35.121,8,32c3.238,2.45,8.125,5,16,5s12.762-2.55,16-5c-2.715,3.121-5.857,4.848-8.639,5.815L33,40c0,0,7.838-0.047,13-6C45.121,19.425,40,12,40,12z M17.5,30c-1.933,0-3.5-1.791-3.5-4c0-2.209,1.567-4,3.5-4s3.5,1.791,3.5,4C21,28.209,19.433,30,17.5,30z M30.5,30c-1.933,0-3.5-1.791-3.5-4c0-2.209,1.567-4,3.5-4s3.5,1.791,3.5,4C34,28.209,32.433,30,30.5,30z"></path></svg>
    </button>
  </div>
</div>
  </ul>
    <button type="button" id="scrollToTopBtn"class="button2" style="left:340%"> Scroll To top</button>
</div>
<p style="text-align:right;color:white;justify-content:center">&copy; 2023 My Website. All rights reserved.-</p>
    </footer>

  <script>// Smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();

    document.querySelector(this.getAttribute('href')).scrollIntoView({
      behavior: 'smooth'
    });
  });
});
//loader
window.addEventListener('load', function() {
  const loader = document.querySelector('.loader');
  const content = document.querySelector('.content');

  // Hide loader and show content after delay (e.g., 2 seconds)
  setTimeout(function() {
    loader.style.display = 'none';
    content.style.display = 'block';
  }, 00);
});
//button scroll up
let scrollBtn=document.getElementById("scrollToTopBtn")

scrollBtn.addEventListener("click",()=>{
  window.scrollTo({top : 0,behavior:'smooth'})
})
</script>
</body>
</html>