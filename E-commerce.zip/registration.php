<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AJDEV REG </title>
    <style>
        body{
    background: url("https://images.pexels.com/photos/3265437/pexels-photo-3265437.jpeg?auto=compress&cs=tinysrgb&w=1600 ");
   font-family:Verdana, Geneva, Tahoma, sans-serif;
   background-size:cover;
  background-repeat: no-repeat;  
}
.regform{
    width:500px;
    margin:250px auto;
    padding:10px 20px 30px;
    background-color: rgba(0,0,0,.5);
    background:url("https:/images.pexels.com/photos/3137052/pexels-photo-3137052.jpeg?auto=compress&cs=tinysrgb&w=1600");
    box-shadow: rgba(15, 14, 14, 0.25) 0px 25px 50px -12px;
    color:rgb(0, 0, 0);
    font-size:30px;
    border-radius:10px;
}

.regform h3{
    text-align: center;
    color:#201410;
}

.regform .textlabel{
    display:block;
}

.input input{
    width:100%;
    font-size:1.2em;
    border: 1px solid #86e5ee;
    box-shadow: rgba(0, 0, 0, 0.4) 0px 30px 90px;
    border-radius: 8px;
    padding: 10px 10px;
    box-sizing:border-box;
    margin:5px 0px 15px;
}

input:focus{
    background-color: #83C5BE;
}

.btn{
    text-align: center;
}

button{
    background-color: #83C5BE;
    font-size:30px;
    color:white;
    margin-top:20px;
    padding:15px 25px;
    border-radius:8px;
    border: 1px solid #006D77;
    box-shadow:2px;
}

.radio input{
    accent-color: #83C5BE;
    transform:scale(1.5);
    -ms-transform: scale(1.5);
    -webkit-transform: scale(1.5); 
}
        </style>

</head>
<body>
    <div class="regform">
        <h3>Registration Form</h3>
        <form action="">    
            <div class="input">
                <label class="textlabel" for="name">First Name</label>
                <input type="text" id="name" name="name">
            </div>
            <div class="input">
                <label class="textlabel" for="name">Last Name</label>
                <input type="name" name="name" id="name">
            </div>
            <div class="input">
                <label class="textlabel" for= "E-mail">E-mail</label>
                <input type="email" name="email" id="E-mail" >
            </div>
            <div class="input">
                <label class="textlabel" for="phone">Phone</label>
                <input type="phone" name="phine" id="phone">
            </div>

            <div class="radio">
                <input type="radio" name="gender" id="male" value="male">
                <label for="male">Male</label>
                <input type="radio" name="gender" id="female" value="female">
                <label for="female">Female</label>
            </div>
            <div class="btn">
                <button type="submit">Register</button>
            </div>
        </form>
    </div>
</body>
</html>